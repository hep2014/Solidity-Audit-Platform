// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/*
Уязвимость:
tx.origin authentication
*/
contract TxOriginWallet {
    address public owner;

    constructor() payable {
        owner = msg.sender;
    }

    function withdrawAll(address payable to) external {
        require(tx.origin == owner, "not owner");
        to.transfer(address(this).balance);
    }

    receive() external payable {}
}
