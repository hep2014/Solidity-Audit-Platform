// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/*
Уязвимость:
Предсказуемая псевдослучайность
*/
contract InsecureRandom {
    function random() external view returns (uint256) {
        return uint256(
            keccak256(
                abi.encodePacked(
                    block.timestamp,
                    block.prevrandao,
                    msg.sender
                )
            )
        ) % 100;
    }
}
