// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "forge-std/Test.sol";

import "../src/VulnerableBank.sol";
import "../src/ReentrancyAttacker.sol";
import "../src/InsecureRandom.sol";
import "../src/TxOriginWallet.sol";
import "../src/OverflowToken.sol";

contract VulnerableTest is Test {
    VulnerableBank bank;
    ReentrancyAttacker attacker;
    InsecureRandom rnd;
    TxOriginWallet wallet;
    OverflowToken token;

    function setUp() public {
        bank = new VulnerableBank();
        attacker = new ReentrancyAttacker(address(bank));
        rnd = new InsecureRandom();
        wallet = new TxOriginWallet();
        token = new OverflowToken();

        vm.deal(address(this), 20 ether);
        vm.deal(address(attacker), 2 ether);

        payable(address(bank)).transfer(5 ether);
        payable(address(wallet)).transfer(3 ether);
    }

    function testRandom() public view {
        rnd.random();
    }

    function testOverflow() public {
        token.transfer(address(1), 5000);
    }

    function testReentrancyAttack() public {
        attacker.attack{value: 1 ether}();
    }
}
