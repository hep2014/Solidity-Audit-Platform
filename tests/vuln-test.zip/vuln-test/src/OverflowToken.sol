// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/*
Уязвимость:
unchecked arithmetic
*/
contract OverflowToken {
    mapping(address => uint256) public balanceOf;

    constructor() {
        balanceOf[msg.sender] = 1000;
    }

    function transfer(address to, uint256 amount) external {
        unchecked {
            balanceOf[msg.sender] -= amount;
            balanceOf[to] += amount;
        }
    }
}
