// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/*
    Проект специально содержит уязвимость для fuzz/property-based анализа Echidna.

    Уязвимость:
    withdraw() отправляет эфир пользователю, но не уменьшает внутренний баланс.
    Из-за этого один и тот же депозит можно вывести несколько раз.

    Инвариант:
    Баланс контракта должен быть не меньше суммы внутренних балансов пользователей.

    Echidna должна найти последовательность:
    1. deposit()
    2. withdraw()
    После withdraw внутренний accounting balance не уменьшается,
    а ETH из контракта уходит.
*/

contract VulnerableVault {
    mapping(address => uint256) public balances;

    address[] public users;
    mapping(address => bool) public knownUser;

    function deposit() external payable {
        require(msg.value > 0, "zero deposit");

        if (!knownUser[msg.sender]) {
            knownUser[msg.sender] = true;
            users.push(msg.sender);
        }

        balances[msg.sender] += msg.value;
    }

    function withdraw(uint256 amount) external {
        require(balances[msg.sender] >= amount, "not enough balance");
        require(amount > 0, "zero amount");

        // УЯЗВИМОСТЬ:
        // ETH отправляется, но balances[msg.sender] не уменьшается.
        (bool ok, ) = msg.sender.call{value: amount}("");
        require(ok, "transfer failed");

        // Должно быть:
        // balances[msg.sender] -= amount;
    }

    function totalInternalBalances() public view returns (uint256 total) {
        for (uint256 i = 0; i < users.length; i++) {
            total += balances[users[i]];
        }
    }

    function echidna_contract_balance_covers_internal_balances()
        external
        view
        returns (bool)
    {
        return address(this).balance >= totalInternalBalances();
    }

    receive() external payable {}
}
