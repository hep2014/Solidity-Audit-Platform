// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/*
Уязвимость:
Reentrancy
*/
contract VulnerableBank {
    mapping(address => uint256) public balances;

    function deposit() external payable {
        balances[msg.sender] += msg.value;
    }

    function withdraw(uint256 amount) external {
        require(balances[msg.sender] >= amount, "not enough");

        // Внешний вызов ДО изменения состояния
        (bool ok,) = msg.sender.call{value: amount}("");
        require(ok, "transfer failed");

        balances[msg.sender] -= amount;
    }

    receive() external payable {}
}
